# Slack-LAMP-Architecture
Website similar to SLACK using LAMP architecture
